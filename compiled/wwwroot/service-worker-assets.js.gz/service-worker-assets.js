﻿self.assetsManifest = {
  "assets": [
    {
      "hash": "sha256-D97p7DBzh7VxziQKbK4K6EMRMfyDM4isTu3FhS5tbQE=",
      "url": "app.json"
    },
    {
      "hash": "sha256-JZmZJ\/CYfyppk8WlohtgEGN8AxlLFMD25EQOiz8Q5y0=",
      "url": "css\/app.css"
    },
    {
      "hash": "sha256-E3k5zz3gok+ifulPfwpZIsh1oTGBJJc5ggP7YuAs7e8=",
      "url": "css\/brixi.css"
    },
    {
      "hash": "sha256-HSnxmsQmuIAavjJzSTK4XA8dW7VnTTRT1q7+a1+YDis=",
      "url": "css\/buttons.css"
    },
    {
      "hash": "sha256-oK0i25+YuvTrePhjQAnTzdhw3VOIZnpS6bVC9gE+c8M=",
      "url": "css\/form.css"
    },
    {
      "hash": "sha256-65gGAL9XqNBnFN5CX5nxF8NQa1qbZhlMHgGt1QaKqIo=",
      "url": "css\/game.css"
    },
    {
      "hash": "sha256-sTX0xm0142nNOPXAIhXt3rjJ7aAmRSD1v9xH+M1FDSU=",
      "url": "css\/input.css"
    },
    {
      "hash": "sha256-7BF4lc46UCSEJq\/hRNllSUdOlK\/iq6Neh5plzBtGy5g=",
      "url": "css\/lightswitch.css"
    },
    {
      "hash": "sha256-CnChzBrOFlQ1BJT+e3DQuven4I+CEBcFq86zaorN4CI=",
      "url": "css\/normalize.css"
    },
    {
      "hash": "sha256-9vub\/Ova2RPe+8L7zqJbGxWDt+OduFiDVIoDcOCBkE8=",
      "url": "css\/select.css"
    },
    {
      "hash": "sha256-5o5VF1gLkCZaGgjG3IsJEjwmNE5lOAeK3PZmiO4a490=",
      "url": "css\/tabletop.css"
    },
    {
      "hash": "sha256-8YEWLaik+IrnUQte4WgoNoxrSrF2X8T4YMtV7+4KeUs=",
      "url": "css\/toast.css"
    },
    {
      "hash": "sha256-IpHFcQvs03lh6W54zoeJRG1jW+VnGmwymzxLoXtKX7Y=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-af2ggFldh2zHjxoxCImeR3vCkNtzkaJtMLySQQgViYY=",
      "url": "icons\/icon-120x120.png"
    },
    {
      "hash": "sha256-TcAsZzaq3c07d5swQRZaci5+d4eJq2\/hM29vV3NnYRk=",
      "url": "icons\/icon-128x128.png"
    },
    {
      "hash": "sha256-QubdV2i3ah7U3cflsQ63ez\/51WaDJ4hAYPOZlrbdLZs=",
      "url": "icons\/icon-144x144.png"
    },
    {
      "hash": "sha256-mFwf2efWToW4EPMoS7BgLDS5v98YXZ0fKobHbGh6Xn8=",
      "url": "icons\/icon-152x152.png"
    },
    {
      "hash": "sha256-DjNJjfm\/s\/1sfAQQzNRZ6ugC28D4WG+dqSHSqR+OVIE=",
      "url": "icons\/icon-167x167.png"
    },
    {
      "hash": "sha256-yA2Wm+w6lEUsnPdtN2tGhqXKMvsmBVY\/HmPtcAexhb8=",
      "url": "icons\/icon-16x16.png"
    },
    {
      "hash": "sha256-AU\/QO+eRU7SyLzQV37hO\/8u9S0Lnee1QSM3JltiIGEA=",
      "url": "icons\/icon-180x180.png"
    },
    {
      "hash": "sha256-AJz7XROidJtYxN2e95GKGkYxeW3hCbKNIrQrwYatXnc=",
      "url": "icons\/icon-192x192.png"
    },
    {
      "hash": "sha256-Ls+w7iZb5DYIsMBWV9Z61u0GY2nwl8M4yGj076BW6FI=",
      "url": "icons\/icon-256x256.png"
    },
    {
      "hash": "sha256-vzIs3v9TFU2hLz2K8zeAnnM67qkkIft8WG\/crPwRwzw=",
      "url": "icons\/icon-32x32.png"
    },
    {
      "hash": "sha256-TSpz7u0BAb8ACwkxQfQWw87VCdDeQwy6q4iegscb4+k=",
      "url": "icons\/icon-512x512.png"
    },
    {
      "hash": "sha256-n\/YdslL0J2YBfJy9fCdgq4OJLP3HuopfYW84XdjMr2Y=",
      "url": "icons\/icon-96x96.png"
    },
    {
      "hash": "sha256-0cjfDWtI14iSTLCgQS8+ZIijuj69chehVVfMZsUyt2o=",
      "url": "icons\/maskable\/icon-128x128.png"
    },
    {
      "hash": "sha256-t7q0iqnK5pusJHvwQy4M1h+\/WvvYsdap+qFjEqgyRyY=",
      "url": "icons\/maskable\/icon-144x144.png"
    },
    {
      "hash": "sha256-96CletG1HnyALIOdm2R7tJDdsD04fZMy92k6VgIp5WU=",
      "url": "icons\/maskable\/icon-152x152.png"
    },
    {
      "hash": "sha256-zgbo3gpMR9r4rpXpay6s1l47fUFU7MyEdN0PceJDwy0=",
      "url": "icons\/maskable\/icon-192x192.png"
    },
    {
      "hash": "sha256-Fjqg3hpOVd4LErHd7DxCG8xAuguU0cUuMqckF0A3nVY=",
      "url": "icons\/maskable\/icon-256x256.png"
    },
    {
      "hash": "sha256-K+TNeSzdQw+HH+hN1B5A+XrTAeQ8ck8VBQ+7OWBvWK4=",
      "url": "icons\/maskable\/icon-512x512.png"
    },
    {
      "hash": "sha256-B8gUyG+W6h1YV6TycjhTozXU7\/GLMajyEcMZbDIlMR4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Q3CzGK\/p8YlnBer9fj3Twtn+Oo5ra10dFvV1\/y4gXK4=",
      "url": "js\/chat-modal.js"
    },
    {
      "hash": "sha256-tHwcUcHBOK8vPmj1064ymLiVJgT\/SBXMhGcR\/km1FYE=",
      "url": "js\/combat-modal.js"
    },
    {
      "hash": "sha256-wRxH0H3d\/gczX2UQpEqkNVMdJGyJXRY1z66FZwRaXko=",
      "url": "js\/creature-manager.js"
    },
    {
      "hash": "sha256-cQbotzgeoEtIgUsY9oeWYHElCIMA9\/yH+\/tFGxqozok=",
      "url": "js\/db-worker.js"
    },
    {
      "hash": "sha256-AOTkfyTDlvRC6rhagp6YGCZNRHvUD2gokbaY011M36g=",
      "url": "js\/dice.js"
    },
    {
      "hash": "sha256-oQFQQw3amG1MPs7Go5Nz6VGfGoVOeSmYEYFzLdBaltU=",
      "url": "js\/globals.js"
    },
    {
      "hash": "sha256-UuVyPNpwFKccvpQoa09kzMrC7512h2+U7XxrLIQV11U=",
      "url": "js\/notifications.js"
    },
    {
      "hash": "sha256-kZJNLZX8jMVH6rkq9CkbkXDlwzXNhMeokajzQUOEGHs=",
      "url": "js\/notify.js"
    },
    {
      "hash": "sha256-h7l+JaPzcmIRdo1YlROuYC1wQh1BZ\/6DSlsbHncdmkQ=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-KPrV4IZfzlNQpR9+NGk7RrFQmipUScTnWUcTrNjRDR8=",
      "url": "service-worker.killer.js"
    },
    {
      "hash": "sha256-tBT4mHTPJ2HOT5KDWFCAaiZvcrEbwItLNw4dogLcdyM=",
      "url": "sfx\/alert.wav"
    },
    {
      "hash": "sha256-6dXbFgLe1mqvRz1bDpOG0s6iNf08wjQPvlAhnzjE2eM=",
      "url": "sfx\/celebration.wav"
    },
    {
      "hash": "sha256-kb5Xnvsbu8TOHtnzrIL3o183uxu1Dvjpa4mcMbRXfao=",
      "url": "sfx\/loading.wav"
    },
    {
      "hash": "sha256-62tX860uhWqb2nsL2qtbJCenusHu7SoPOSjR6Yi\/F8A=",
      "url": "sfx\/message.wav"
    },
    {
      "hash": "sha256-2E6Y+zvQW8f1JZXpqiG2APnjDFhHA5IdSF3T\/aXLdXQ=",
      "url": "sfx\/ping.mp3"
    },
    {
      "hash": "sha256-8PAPusTTUlg0xlarb84WsPXeVu15GOI3CAcKedYvaD0=",
      "url": "sfx\/plop.wav"
    },
    {
      "hash": "sha256-PLzG6CevPdkGe9JKX1mGtn8XdO6SAfJvplMV4GIno88=",
      "url": "sfx\/success.wav"
    },
    {
      "hash": "sha256-7SCvEic7hcuH0JQcWApxTVEu2pYVcCx\/cuooK2aWH4Q=",
      "url": "_framework\/_bin\/FreeTabletop.Client.dll"
    },
    {
      "hash": "sha256-63Neea+hwIeZGAMikhMskSYQeg+JsjKi15UYKfmg\/bs=",
      "url": "_framework\/_bin\/FreeTabletop.Shared.dll"
    },
    {
      "hash": "sha256-qnk0khenPTGvBBOXXOGxcUOhEIL2GNu1yRegRnxXkpA=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.dll"
    },
    {
      "hash": "sha256-kTUkoVxFscvcjtXpUvCt2c64KW0HlY1x6qR7SWFBZ8w=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.Forms.dll"
    },
    {
      "hash": "sha256-2X2nQEGjLLUrrFBfQJAjtoN+Ii6jgDF263+InPEDC1Y=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.Web.dll"
    },
    {
      "hash": "sha256-QG3ZqvXqx4cG5TEG1CHALI38SPSUt35wKlM7SR\/tG7I=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.WebAssembly.dll"
    },
    {
      "hash": "sha256-1A5My9urKfrgFE0pCLLnT4Wf43k1Tb5eghkwQmll740=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Connections.Abstractions.dll"
    },
    {
      "hash": "sha256-l\/1FqYaYA5qRfLL3+w8McOwXqw1b3SttRKEHzn2GbV8=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Http.Connections.Client.dll"
    },
    {
      "hash": "sha256-ssjyrRSF0JoNqCzIPVxm0rAh4pm3tAHCVkSorkDLy7c=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Http.Connections.Common.dll"
    },
    {
      "hash": "sha256-rjUzVQzrZAS3f\/zzztrKFlHweQYIkEuCUeIncR8xV3U=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Http.Features.dll"
    },
    {
      "hash": "sha256-KWFmM8dlw459ainl1XoqZWJMu+WHhrMzZZTGK4RUZFU=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.SignalR.Client.Core.dll"
    },
    {
      "hash": "sha256-VrFhgqcKLoapdpojjk2rFcSwt4NZ8b+pXfe82YaFLYE=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.SignalR.Client.dll"
    },
    {
      "hash": "sha256-ECcBcmkooGsG\/ddKJcsdyHaAcnDX09T0\/NsYB4JRuGU=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.SignalR.Common.dll"
    },
    {
      "hash": "sha256-dO\/xqNs66tTWJkXUwxiLkukGcvTV8NFrXRAFC8MkURU=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.SignalR.Protocols.Json.dll"
    },
    {
      "hash": "sha256-jzHgXWAvWMkKIGFjZoT84tbe72E+H7CvTr\/Dryh4QPs=",
      "url": "_framework\/_bin\/Microsoft.Bcl.AsyncInterfaces.dll"
    },
    {
      "hash": "sha256-ZMMoTC07yJicoM6BcXBn2dEAD8JHVkGo7AsMr5q8IcI=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.Abstractions.dll"
    },
    {
      "hash": "sha256-iBpm+p+AGX2CT+JgRZERXrjkMOyyCVc5ioF3efB8Nc4=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.dll"
    },
    {
      "hash": "sha256-OHMdFq27QKd3N4Qb+W7z3iv\/L6mcnjXqx1jsTjJxD5g=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.Json.dll"
    },
    {
      "hash": "sha256-FS+FKQa6mQ8s5xAyhPE2UD+558GzErM5E8ORo2W5l6c=",
      "url": "_framework\/_bin\/Microsoft.Extensions.DependencyInjection.Abstractions.dll"
    },
    {
      "hash": "sha256-4Ez9fsWpwG28qu6qjm\/4VX8wi6ZAPdMqy3\/tvNlm7Ww=",
      "url": "_framework\/_bin\/Microsoft.Extensions.DependencyInjection.dll"
    },
    {
      "hash": "sha256-goMYEZjGLT7fdZu1F1TRiswrHmrjqYUAmGBkuS9DFoQ=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Logging.Abstractions.dll"
    },
    {
      "hash": "sha256-IHKn+XcfK1ZZS0jz+F9HrG9N7BK4bGt3c04diwCeoIk=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Logging.dll"
    },
    {
      "hash": "sha256-FmAbf\/MD6p9dGxM2NL5UuJ\/r1l+9kmX9v9dQrYYjaJ4=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Options.dll"
    },
    {
      "hash": "sha256-CJcdreHaiWNrra8v6hLnxO2+9vUC8Gj9PhJ\/13BltkU=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Primitives.dll"
    },
    {
      "hash": "sha256-3cbvJEo8k8VJVQwyEZWWQ6yGRFQW8\/219DaOnmsX3e4=",
      "url": "_framework\/_bin\/Microsoft.JSInterop.dll"
    },
    {
      "hash": "sha256-zV\/OfJNfNsG404X30Pwkdymdh1KmZpTVEmG\/JNFVc\/k=",
      "url": "_framework\/_bin\/Microsoft.JSInterop.WebAssembly.dll"
    },
    {
      "hash": "sha256-AjPi5a6lNmLJRQAgzS+zffxWBcJ5\/vaq5cc7FQORNP8=",
      "url": "_framework\/_bin\/Mono.Security.dll"
    },
    {
      "hash": "sha256-GsIdxmPL7d1HGQrDnpBIq\/wWQIf1M7724N2S7ewIhS4=",
      "url": "_framework\/_bin\/mscorlib.dll"
    },
    {
      "hash": "sha256-8+aWlQshkso8ei8xp5J0gn4ZNGRYRMqXzI+osKzgVYI=",
      "url": "_framework\/_bin\/Newtonsoft.Json.dll"
    },
    {
      "hash": "sha256-+9y537RL3fe5F7hHR5VXuRm\/\/GRrbRswt6\/5QLvPWE0=",
      "url": "_framework\/_bin\/System.ComponentModel.DataAnnotations.dll"
    },
    {
      "hash": "sha256-BfFY4rLEqdKCV+yEeGWiXgPn61sguNtTljpZkbL6\/pk=",
      "url": "_framework\/_bin\/System.Core.dll"
    },
    {
      "hash": "sha256-az68URFFwVQHZVzNqSEdMoJu0V0wn0gDOn5yfcmO0t0=",
      "url": "_framework\/_bin\/System.Data.dll"
    },
    {
      "hash": "sha256-5ewWKGr6OUwWfkCEDKJp9mdQ9jTyfXN0zqBaAE0OLfU=",
      "url": "_framework\/_bin\/System.dll"
    },
    {
      "hash": "sha256-IRCOEmOUWKy6qDEBnTdR3EaSyxeyON+Xmz+pv+Lw0g8=",
      "url": "_framework\/_bin\/System.IO.Pipelines.dll"
    },
    {
      "hash": "sha256-xetSY8vQRU8uqOtfWlwsKzl\/r7qnHqP2o+Rre+0tEZM=",
      "url": "_framework\/_bin\/System.Net.Http.dll"
    },
    {
      "hash": "sha256-KoVxDM6pOZ0g92pq4xDEnJMjUi7JLFUVU\/KraJYNq80=",
      "url": "_framework\/_bin\/System.Net.Http.WebAssemblyHttpHandler.dll"
    },
    {
      "hash": "sha256-veIWfKQ2iurKbjQp8Aji+5ZCBRm\/XFaOjtdZozhCKJg=",
      "url": "_framework\/_bin\/System.Numerics.dll"
    },
    {
      "hash": "sha256-a6vlXL8wG1f5gTOkK14WEnhtdUuPjaiFoq0pTis3u04=",
      "url": "_framework\/_bin\/System.Runtime.CompilerServices.Unsafe.dll"
    },
    {
      "hash": "sha256-nWAYlGWDenSKJeyCzlXzkmNNcP1yDZAZvBKLy59U6PM=",
      "url": "_framework\/_bin\/System.Runtime.Serialization.dll"
    },
    {
      "hash": "sha256-XFOKQsq4N1wyFG7N\/jj2MOWY4fRuesaMTwZW6wIlK4E=",
      "url": "_framework\/_bin\/System.Text.Encodings.Web.dll"
    },
    {
      "hash": "sha256-xrDBbGtbuTblqdMIJKKdS1Jftg2bHAg8M5OIdfdiXao=",
      "url": "_framework\/_bin\/System.Text.Json.dll"
    },
    {
      "hash": "sha256-f4yjub16I++r61kwruuWDcmX5hyiz7SvmBLhKd0a3qI=",
      "url": "_framework\/_bin\/System.Threading.Channels.dll"
    },
    {
      "hash": "sha256-oWBvR0HhRFz0qOR5hUAH8iNOsckVQV+4R\/GcPx3ULxk=",
      "url": "_framework\/_bin\/System.Xml.dll"
    },
    {
      "hash": "sha256-UTcC86iwr2kp6y3VTyK46LT7U2hmmOhmGCBcTP1i+68=",
      "url": "_framework\/_bin\/System.Xml.Linq.dll"
    },
    {
      "hash": "sha256-LTtko10rhBu5Iollube0Wmpft74XH\/Y1TlnOvTKcAgQ=",
      "url": "_framework\/_bin\/WebAssembly.Bindings.dll"
    },
    {
      "hash": "sha256-m6uEwEipAEKN29F5jF9cGp0CeJfR8hgAQTsPTcsNJNc=",
      "url": "_framework\/_bin\/WebAssembly.Net.WebSockets.dll"
    },
    {
      "hash": "sha256-mPoqx7XczFHBWk3gRNn0hc9ekG1OvkKY4XiKRY5Mj5U=",
      "url": "_framework\/wasm\/dotnet.3.2.0.js"
    },
    {
      "hash": "sha256-3S0qzYaBEKOBXarzVLNzNAFXlwJr6nI3lFlYUpQTPH8=",
      "url": "_framework\/wasm\/dotnet.timezones.dat"
    },
    {
      "hash": "sha256-UC\/3Rm1NkdNdlIrzYARo+dO\/HDlS5mhPxo0IQv7kma8=",
      "url": "_framework\/wasm\/dotnet.wasm"
    },
    {
      "hash": "sha256-SPHS1EAPAcMFN4TEIUYl3FWtoCQTsNJch0XVGgok1eE=",
      "url": "_framework\/blazor.webassembly.js"
    },
    {
      "hash": "sha256-MpYFGYEAl63VFR6W2LBo0Q9jmiEOTmdi7kX+PZz\/Oew=",
      "url": "_framework\/blazor.boot.json"
    }
  ],
  "version": "MjFFugAH"
};
